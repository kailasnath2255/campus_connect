-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 15, 2020 at 08:54 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `college_book`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_year`
--

CREATE TABLE IF NOT EXISTS `academic_year` (
  `year_id` int(100) NOT NULL AUTO_INCREMENT,
  `academic_year` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`year_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `academic_year`
--

INSERT INTO `academic_year` (`year_id`, `academic_year`) VALUES
(1, '2016-2019'),
(2, '2017-2019'),
(3, '2018-2020'),
(4, '2017-2020');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE IF NOT EXISTS `attendance` (
  `att_id` int(100) NOT NULL AUTO_INCREMENT,
  `stud_id` varchar(100) DEFAULT NULL,
  `teacher_id` varchar(100) DEFAULT NULL,
  `attendance` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `c_id` varchar(100) DEFAULT NULL,
  `y_id` varchar(100) DEFAULT NULL,
  `semester` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`att_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`att_id`, `stud_id`, `teacher_id`, `attendance`, `date`, `c_id`, `y_id`, `semester`) VALUES
(9, '4', '7', '5', '2019-12-18', '6', '3', '1 SEMESTER'),
(10, '5', '7', '0', '2019-12-18', '6', '3', '1 SEMESTER');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `course_id` int(100) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(100) DEFAULT NULL,
  `course_duration` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `course_duration`) VALUES
(1, 'B. Sc ', '3'),
(2, 'B.SC PYSICS VOCATIONAL', '3'),
(5, 'B.SC PYSICS', '3'),
(6, 'BCA', '3');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE IF NOT EXISTS `exam` (
  `exam_id` int(100) NOT NULL AUTO_INCREMENT,
  `course_id` varchar(100) DEFAULT NULL,
  `academic_year` varchar(100) DEFAULT NULL,
  `semester` varchar(100) DEFAULT NULL,
  `exam_name` varchar(100) DEFAULT NULL,
  `exam_detail` varchar(100) DEFAULT NULL,
  `posted_date` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`exam_id`, `course_id`, `academic_year`, `semester`, `exam_name`, `exam_detail`, `posted_date`) VALUES
(1, '6', '4', '1 SEMESTER', 'First Internal Examination', 'hsgfgsgaddfgasgf', '2019-12-13'),
(2, '6', '3', '2 SEMESTER', 'First internal Examination', 'hdjghjdsfhglhsdfg', '2019-12-13'),
(3, '6', '3', '1 SEMESTER', 'Second internal Examinations ', 'staring from the next week onwards', '2019-12-13');

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE IF NOT EXISTS `fees` (
  `exam_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` varchar(50) NOT NULL,
  `academic_year` varchar(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `feedesc` varchar(50) NOT NULL,
  `posted_date` date NOT NULL,
  PRIMARY KEY (`exam_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`exam_id`, `course_id`, `academic_year`, `semester`, `feedesc`, `posted_date`) VALUES
(1, '6', '4', '1 SEMESTER', 'sem fee rs.15000 .... pay fee before jun 12 2020', '2020-03-12');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `login_id` int(100) NOT NULL AUTO_INCREMENT,
  `register_id` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `status` varchar(10) DEFAULT '0',
  `attendance` varchar(100) DEFAULT '0',
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `register_id`, `username`, `password`, `type`, `status`, `attendance`) VALUES
(1, '0', 'admin', 'admin123', 'admin', '1', '0'),
(8, '7', 'megha@gmail.com', 'megha', 'teacher', '1', '1'),
(10, '9', 'priya@gmail.com', 'priya', 'teacher', '1', '0'),
(11, '1', '8089653256', '1000', 'parent', '1', '0'),
(12, '1000023', 'meera@gmail.com', '1000023', 'student', '1', '0'),
(13, '0', '9656635187', '1832383630', 'parent', '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `mark`
--

CREATE TABLE IF NOT EXISTS `mark` (
  `mark_id` int(100) NOT NULL AUTO_INCREMENT,
  `exam_id` varchar(100) DEFAULT NULL,
  `student_id` varchar(100) DEFAULT NULL,
  `course_id` varchar(100) DEFAULT NULL,
  `academic_year` varchar(100) DEFAULT NULL,
  `semester` varchar(100) DEFAULT NULL,
  `sub1` varchar(100) DEFAULT NULL,
  `sub2` varchar(100) DEFAULT NULL,
  `sub3` varchar(100) DEFAULT NULL,
  `sub4` varchar(100) DEFAULT NULL,
  `sub5` varchar(100) DEFAULT NULL,
  `sub6` varchar(100) DEFAULT NULL,
  `marks_got` varchar(100) DEFAULT NULL,
  `total_mark` varchar(100) DEFAULT '150',
  `percentage_mark` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`mark_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `mark`
--

INSERT INTO `mark` (`mark_id`, `exam_id`, `student_id`, `course_id`, `academic_year`, `semester`, `sub1`, `sub2`, `sub3`, `sub4`, `sub5`, `sub6`, `marks_got`, `total_mark`, `percentage_mark`, `status`) VALUES
(3, '3', '5', '6', '3', '1 SEMESTER', 'null', 'null', 'null', 'null', 'null', 'null', 'null', '150', 'null', 'absent'),
(4, '3', '4', '6', '3', '1 SEMESTER', '20', '23', '25', '21', '22', '24', '135', '150', '90.0', 'passed');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `register_id` int(100) NOT NULL AUTO_INCREMENT,
  `register_name` varchar(100) DEFAULT NULL,
  `register_mail` varchar(100) DEFAULT NULL,
  `register_phone` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`register_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`register_id`, `register_name`, `register_mail`, `register_phone`) VALUES
(7, 'Megha T B', 'megha@gmail.com', '8028147457'),
(9, 'priya', 'priya@gmail.com', '9908295472');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `stud_id` int(100) NOT NULL AUTO_INCREMENT,
  `stud_register_no` varchar(100) DEFAULT NULL,
  `stud_name` varchar(100) DEFAULT NULL,
  `stud_mail` varchar(100) DEFAULT NULL,
  `stud_phone` varchar(100) DEFAULT NULL,
  `parent_name` varchar(100) DEFAULT NULL,
  `parent_phone` varchar(100) DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `academic_year` varchar(100) DEFAULT NULL,
  `semester` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`stud_id`, `stud_register_no`, `stud_name`, `stud_mail`, `stud_phone`, `parent_name`, `parent_phone`, `course`, `academic_year`, `semester`) VALUES
(1, '124364578596807', 'megha', 'megha@gmail.com', '9789678568', 'babu', '9879878164', '2', '2', '2 SEMESTER'),
(4, '100000000000001', 'priya', 'priya@gmail.com', '9879869785', 'jose', '8979879869', '6', '3', '1 SEMESTER'),
(5, '100000000000002', 'dilsha m deleep', 'dilsha@gmail.com', '8697097609', 'deleep', '7878678607', '6', '3', '1 SEMESTER'),
(6, '1000023', 'meera', 'meera@gmail.com', '9563254789', 'unnikrishna', '9656635187', '6', '3', '1 SEMESTER');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `sub_id` int(100) NOT NULL AUTO_INCREMENT,
  `course_id` varchar(50) DEFAULT NULL,
  `semester` varchar(100) DEFAULT NULL,
  `sub1` varchar(100) DEFAULT NULL,
  `sub2` varchar(100) DEFAULT NULL,
  `sub3` varchar(100) DEFAULT NULL,
  `sub4` varchar(100) DEFAULT NULL,
  `sub5` varchar(100) DEFAULT NULL,
  `sub6` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`sub_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`sub_id`, `course_id`, `semester`, `sub1`, `sub2`, `sub3`, `sub4`, `sub5`, `sub6`) VALUES
(1, '6', '1 SEMESTER', 'c', 'CPP', 'PMA', 'digital', 'stati', 'co');
