from django.shortcuts import render

from django.http import (HttpResponse,HttpResponseRedirect)
from django.shortcuts import render
import MySQLdb
import datetime
now = datetime.datetime.now()
import simplejson as json

# Create your views here.


conn = MySQLdb.connect("localhost","root","","college_book")
c = conn.cursor()

def teacher_header_footerview(request):   
    return render(request,"teacher_header_footer.html")

def teacher_homeview(request):   
    return render(request,"teacher_home.html")

def t_view_studentsview(request):   
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    print("inside if")

    if 'search' in request.POST:
        print("inside if")
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        s3 = "select * from student where course='"+str(c_id)+"' and academic_year='"+str(y_id)+"' order by stud_register_no"
        c.execute(s3)
        print(s3)
        conn.commit()
        data2 = c.fetchall()
        print(data2)
        return render(request,"t_view_students.html",{"data":data,"data1":data1,"data2":data2,"c_id":c_id,"y_id":y_id})
    return render(request,"t_view_students.html",{"data":data,"data1":data1})

def t_view_examview(request):  
    # s1 = "select * from course"
    # c.execute(s1)
    # conn.commit()
    # data = c.fetchall()

    # s2 = "select * from academic_year order by academic_year DESC"
    # c.execute(s2)
    # conn.commit()
    # data1 = c.fetchall() 
    

    s = "select * from exam x, course c, academic_year y where x.course_id= c.course_id  and x.academic_year = y.year_id order by exam_id desc" 
    c.execute(s)
    conn.commit()
    print(s)
    data2 = c.fetchall()
    print(data2)
        
    return render(request,"t_view_exam.html",{"data2":data2})
  
def students_listview(request):   
    exam_id = request.GET.get("exam_id")
    c_id = request.GET.get("c_id")
    y_id = request.GET.get("y_id")
    sem = request.GET.get("sem")
    print(exam_id)
    print("inside view")
    s = "select * from student s, course c, academic_year y where s.course = '"+str(c_id)+"' and s.academic_year = '"+str(y_id)+"' and s.semester = '"+str(sem)+"' and c.course_id= '"+str(c_id)+"' and y.year_id = '"+str(y_id)+"'"
    c.execute(s)
    print(s)
    conn.commit()
    data1 = c.fetchall()
    print(data1)
    return render(request,"students_list.html",{"data1":data1,"exam_id":exam_id,"c_id":c_id,"y_id":y_id,"sem":sem})

def add_markview(request):  
    msg = "" 
    exam_id = request.GET.get("exam_id")
    stud_id = request.GET.get("stud_id")
    sem = request.GET.get("sem")
    c_id = request.GET.get("c_id")
    y_id = request.GET.get("y_id")
    print(sem)
    print(exam_id)
    s = "select * from student s,exam x, course c, academic_year y where x.exam_id='"+str(exam_id)+"' and s.stud_id = '"+str(stud_id)+"' and s.course=x.course_id and s.academic_year=x.academic_year and x.semester = s.semester and c.course_id = x.course_id and y.year_id = x.academic_year"
    print(s)
    c.execute(s)
    conn.commit()
    data1 = c.fetchall()
    print(data1)
    print(data1[0][7])
    s1 = "select * from subject s where s.course_id = '"+str(data1[0][7])+"' and s.semester = '"+str(sem)+"' "
    print(s1)
    c.execute(s1)
    conn.commit()
    data2 = c.fetchall()
    print(data2)

    ss = "select count(*) from mark where student_id = '"+str(stud_id)+"' and  exam_id = '"+str(exam_id)+"'"
    c.execute(ss)
    conn.commit()
    st_count = c.fetchone()

    if 'add_mark' in request.POST:
        sub1 = request.POST.get("sub1")
        sub2 = request.POST.get("sub2")
        sub3 = request.POST.get("sub3")
        sub4 = request.POST.get("sub4")
        sub5 = request.POST.get("sub5")
        sub6 = request.POST.get("sub6")
        sb1 = int(sub1)
        sb2 = int(sub2)
        sb3 = int(sub3)
        sb4 = int(sub4)
        sb5 = int(sub5)
        sb6 = int(sub6)
        marks_got = sb1+sb2+sb3+sb4+sb5+sb6
        print(sub1+" "+sub2+" "+sub3)
        print(marks_got)
        percentage_mark = (marks_got/150)*100
        print(percentage_mark)
        if st_count[0] == 0 :
            if (sb1 < 13 or sb2 < 13 or sb3 < 13 or sb4 < 13 or sb5 < 13 or sb6 < 13 or percentage_mark < 50):
                s = " insert into mark(`exam_id`,`student_id`,`course_id`,`academic_year`,`semester`,`sub1`,`sub2`,`sub3`,`sub4`,`sub5`,`sub6`,`marks_got`,`percentage_mark`,`status`) values('"+str(exam_id)+"','"+str(stud_id)+"','"+str(c_id)+"','"+str(y_id)+"','"+str(sem)+"','"+str(sub1)+"','"+str(sub2)+"','"+str(sub3)+"','"+str(sub4)+",'"+str(sub5)+"','"+str(sub6)+"','"+str(marks_got)+"','"+str(percentage_mark)+"','failed')"
                c.execute(s)
                print(s)
                conn.commit()                   
                msg = "Marks Added Successfully"
                return render(request,"add_mark.html",{"data1":data1,"data2":data2,"msg":msg})
            else:
                s = " insert into mark(`exam_id`,`student_id`,`course_id`,`academic_year`,`semester`,`sub1`,`sub2`,`sub3`,`sub4`,`sub5`,`sub6`,`marks_got`,`percentage_mark`,`status`) values('"+str(exam_id)+"','"+str(stud_id)+"','"+str(c_id)+"','"+str(y_id)+"','"+str(sem)+"','"+str(sub1)+"','"+str(sub2)+"','"+str(sub3)+"','"+str(sub4)+"','"+str(sub5)+"','"+str(sub6)+"','"+str(marks_got)+"','"+str(percentage_mark)+"','passed')"
                c.execute(s)
                print(s)
                conn.commit()                   
                msg = "Marks Added Successfully"
                return render(request,"add_mark.html",{"data1":data1,"data2":data2,"msg":msg})
            return render(request,"add_mark.html",{"data1":data1,"data2":data2,"msg":msg})
        else:
            msg = "Marks Are Already Added"
        return render(request,"add_mark.html",{"data1":data1,"data2":data2,"msg":msg})

    if 'mark_absent' in request.POST:
        if st_count[0] == 0 :
            s = " insert into mark(`exam_id`,`student_id`,`course_id`,`academic_year`,`semester`,`sub1`,`sub2`,`sub3`,`sub4`,`sub5`,`sub6`,`marks_got`,`percentage_mark`,`status`) values('"+str(exam_id)+"','"+str(stud_id)+"','"+str(c_id)+"','"+str(y_id)+"','"+str(sem)+"','null','null','null','null','null','null','null','null','absent')"
            c.execute(s)
            print(s)
            conn.commit()
            msg = "Absent Marked Successfully"
            return render(request,"add_mark.html",{"data1":data1,"data2":data2,"msg":msg})
        else:
            msg = "Absent is Marked Already"
            return render(request,"add_mark.html",{"data1":data1,"data2":data2,"msg":msg})    
        return render(request,"add_mark.html",{"data1":data1,"data2":data2,"msg":msg})    

    return render(request,"add_mark.html",{"data1":data1,"data2":data2,"msg":msg})

def t_result_view(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall() 
    
    if 'view_exam' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        print("inside if")

        s = "select * from exam x , course c, academic_year y where c.course_id = '"+str(c_id)+"' and  x.course_id =  '"+str(c_id)+"' and y.year_id = '"+str(y_id)+"' and x.semester = '"+str(semester)+"' and x.academic_year =  '"+str(y_id)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        return render(request,"view_result.html",{"data":data,"data1":data1,"data2":data2,"sem":semester})
    return render(request,"view_result.html",{"data":data,"data1":data1})


def result_view(request):  
    msg = "" 
    exam_id = request.GET.get("exam_id")
    c_id = request.GET.get("c_id")
    y_id = request.GET.get("y_id")
    sem = request.GET.get("sem")
    print(exam_id)
    print("inside view")
    s = "select * from student s, course c, academic_year y,mark m where s.course = '"+str(c_id)+"' and s.academic_year = '"+str(y_id)+"' and s.semester = '"+str(sem)+"' and c.course_id= '"+str(c_id)+"' and y.year_id = '"+str(y_id)+"' and m.exam_id='"+str(exam_id)+"' and m.student_id = s.stud_id"
    c.execute(s)
    print(s)
    conn.commit()
    data1 = c.fetchall()
    print(data1)

    s1 = "select * from exam where exam_id ='"+str(exam_id)+"'"
    c.execute(s1)
    print(s1)
    conn.commit()
    data2 = c.fetchall()
    print(data1)

    s2 = "select * from subject where course_id='"+str(c_id)+"' and semester='"+str(sem)+"'"
    c.execute(s2)
    print(s2)
    conn.commit()
    data3 = c.fetchall()
    if not bool(data1):
        msg = " No student list to show"
    return render(request,"view_result_list.html",{"msg":msg,"data1":data1,"exam_id":exam_id,"c_id":c_id,"y_id":y_id,"sem":sem,"data2":data2,"data3":data3})


def t_attendance_mark(request):
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    today = now.date()
    if 'attendance' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        # period = request.POST.get("period")
        semester = request.POST.get("semester")
        s3 = "select * from student where course='"+str(c_id)+"' and academic_year='"+str(y_id)+"' and semester = '"+str(semester)+"' order by stud_register_no"
        c.execute(s3)
        print(s3)
        conn.commit()
        data2 = c.fetchall()
        print(data2)

        s4 = "select stud_id,attendance from attendance where c_id = '"+str(c_id)+"' and y_id = '"+str(y_id)+"' and semester = '"+str(semester)+"' and date = '"+str(today)+"'"
        c.execute(s4)
        print(s4)
        data4 = c.fetchall()
        print(data4)
        return render(request,"t_attendance_mark.html",{"data":data,"data1":data1,"data2":data2,"data4":data4,"c_id":c_id,"y_id":y_id})

    return render(request,"t_attendance_mark.html",{"data":data,"data1":data1})

def mark_attendance(request):   
    print("haaaiiii")
    msg = ""
    c_id = request.GET.get("c_id")
    y_id = request.GET.get("y_id")
    stud_id = request.GET.get("stud_id")
    semester = request.GET.get("sem")
    status = request.GET.get("status")
    t_id = ""
    today = now.date()

    ss = "select count(*),attendance from attendance where stud_id='"+str(stud_id)+"' and date = '"+str(today)+"'"
    c.execute(ss)
    print(ss)
    conn.commit()
    stud_count = c.fetchone()
    print(stud_count)
    if stud_count[0] == 0 :
        if status == "Attendance":
            print("inside attendance")
            s = "insert into attendance(`stud_id`,`teacher_id`,`attendance`,`date`,`c_id`,`y_id`,`semester`) values('"+str(stud_id)+"','"+str(t_id)+"','5','"+str(today)+"','"+str(c_id)+"','"+str(y_id)+"','"+str(semester)+"')"
            c.execute(s)
            print(s)
            conn.commit()
        if status == "HalfDay":
            print("inside attendance")
            s = "insert into attendance(`stud_id`,`teacher_id`,`attendance`,`date`,`c_id`,`y_id`,`semester`) values('"+str(stud_id)+"','"+str(t_id)+"','2.5','"+str(today)+"','"+str(c_id)+"','"+str(y_id)+"','"+str(semester)+"')"
            c.execute(s)
            print(s)
            conn.commit()
        if status == "Absent":
            ss1 = "select stud_name,parent_phone from student where stud_id='"+str(stud_id)+"'"
            c.execute(ss1)
            print(ss1)
            conn.commit()
            stud_count1 = c.fetchone()
            phno=stud_count1[1]
            stna=stud_count1[0]
            print("inside attendance")
            msg="Your Child '"+str(stna)+"' is absent on '"+str(today)+"' "
            s = "insert into attendance(`stud_id`,`teacher_id`,`attendance`,`date`,`c_id`,`y_id`,`semester`) values('"+str(stud_id)+"','"+str(t_id)+"','0','"+str(today)+"','"+str(c_id)+"','"+str(y_id)+"','"+str(semester)+"')"
            c.execute(s)
            print(s)
            conn.commit()
            return HttpResponseRedirect("http://dattaanjaneya.biz/API_Services/SMS_Service.php?content="+msg+"&mobile="+phno+"")

        msg = "Attendance Successfully Added" 
        return render(request,"t_attendance_mark.html",{"msg":msg})
    else:
        msg = "Already marked"
        return render(request,"t_attendance_mark.html",{"msg":msg})
    return render(request,"t_attendance_mark.html",{"msg":msg})

def view_attendance(request):
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    today = now.date()
    if 'attendance' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        # period = request.POST.get("period")
        semester = request.POST.get("semester")
        s3 = "select * from student s, attendance a where s.course='"+str(c_id)+"' and s.academic_year='"+str(y_id)+"' and s.semester = '"+str(semester)+"' and a.stud_id = s.stud_id and a.c_id = s.course and a.semester = s.semester and a.date = '"+str(today)+"'  order by stud_register_no"
        c.execute(s3)
        print(s3)
        conn.commit()
        data2 = c.fetchall()
        print(data2)

        
        return render(request,"view_attendance.html",{"data":data,"data1":data1,"data2":data2,"c_id":c_id,"y_id":y_id})

    return render(request,"view_attendance.html",{"data":data,"data1":data1})