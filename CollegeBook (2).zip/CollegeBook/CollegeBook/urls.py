"""CollegeBook URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from administrator import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.conf.urls.static import static
from teacher import teacher_views
from parent import parent_views
from student import student_views
urlpatterns = [
    #---------------General Home Page------------------------#
    path('admin/', admin.site.urls),
    path('', views.indexview),
    path('indexview', views.indexview),
    path('registrationview/', views.registrationview),
     path('index_header_footerview/', views.index_header_footerview),


path('payment1/',parent_views.payment1,name='payment1'),
    path('payment2/',parent_views.payment2,name='payment2'),
    path('payment3/',parent_views.payment3,name='payment3'),
    path('payment4/',parent_views.payment4,name='payment4'),
    path('payment5/',parent_views.payment5,name='payment5'),
    #---------------Administrator----------------------------#
    path('admin_header_footerview/', views.admin_header_footerview),
    path('admin_homeview/', views.admin_homeiew),
    path('approve_teacherview/', views.approve_teacherview),
    path('update_approve_teacherview/', views.update_approve_teacherview),
    path('view_teacheriew/', views.view_teacheriew),
    path('add_coursesview/', views.add_coursesview),
    path('view_coursesview/', views.view_coursesview),
    path('academic_yearview/', views.academic_yearview),
    path('add_studentsview/', views.add_studentsview),
    path('view_studentsview/', views.view_studentsview),
    path('del_studentview/', views.del_studentview),
    path('add_subjectview/', views.add_subjectview),
    path('add_examview/', views.add_examview),
    path('view_examview/', views.view_examview),
    path('a_exams/', views.a_exams),
    path('a_view_attendance/', views.a_view_attendance),
    path('teacher_delete/', views.teacher_delete),
    path('send_att_sms/', views.send_att_sms),
    path('add_fee/', views.add_fee),
    path('view_fee/', views.view_fee),
    path('admin_editstudent/', views.admin_editstudent),
    path('add_circular/', views.add_circular),

    path('add_event/', views.add_event),
    path('add_notice/', views.add_notice),
    path('add_achievement/', views.add_achievement),
    path('add_studentachievement/', views.add_studentachievement),
    path('add_material/',views.add_material),
    path('add_result/',views.add_result),
    path('add_studentresult/',views.add_studentresult),
    path('add_meeting/',views.add_meeting),
    path('add_calender/',views.add_calender),
    path('add_timetable/',views.add_timetable),
    path('add_syllabus/',views.add_syllabus),
    path('view_feedback/',views.view_feedback),
    path('add_assignment/',views.add_assignment),
    path('viewmonthly/',views.viewmonthly),


    #---------------Teacher----------------------------#teacher_header_footerview
    path('teacher_header_footerview/', teacher_views.teacher_header_footerview),
    path('teacher_homeview/', teacher_views.teacher_homeview),
    path('t_view_studentsview/', teacher_views.t_view_studentsview),
    path('t_view_examview/', teacher_views.t_view_examview),
    path('students_listview/', teacher_views.students_listview),
    path('add_markview/', teacher_views.add_markview),
    path('t_result_view/', teacher_views.t_result_view),
    path('result_view/', teacher_views.result_view),
    path('t_attendance_mark/', teacher_views.t_attendance_mark),
    path('mark_attendance/', teacher_views.mark_attendance),
    path('view_attendance/', teacher_views.view_attendance),



#---------------Parent----------------------------#parent_header_footerview
    path('parent_header_footerview/', parent_views.parent_header_footerview),
    path('parent_home/', parent_views.parent_home),
    path('parentresult_view/', parent_views.parentresult_view),
    path('parent_view_fee/', parent_views.parent_view_fee),
    path('parent_view_meeting/', parent_views.parent_view_meeting),
    path('add_feedbackparent/', parent_views.add_feedbackparent),

    path('parentview_teacheriew/', parent_views.parentview_teacheriew),

    path('pt_view_attendance/', parent_views.pt_view_attendance),
    path('viewmonthlypar/', parent_views.viewmonthlypar),



#---------------Student----------------------------#student_header_footerview
    path('student_header_footerview/', student_views.student_header_footerview),
    path('student_home/', student_views.student_home),
     path('studentresult_view/', student_views.studentresult_view),
      path('view_circular/', student_views.view_circular),
    # path('parent_view_fee/', parent_views.parent_view_fee),

      path('view_result/', student_views.view_result),
      path('view_notice/', student_views.view_notice),
      path('view_event/', student_views.view_event),
      path('view_material/', student_views.view_material),
      path('view_academic/', student_views.view_academic),

      path('view_syllabus/', student_views.view_syllabus),
      path('add_feedback/', student_views.add_feedback),
    path('studentview_teacheriew/', student_views.studentview_teacheriew),
    path('view_assignment/', student_views.view_assignment),
    path('viewmonthlystu/', student_views.viewmonthlystu),
    path('stu_view_attendance/', student_views.stu_view_attendance),



]+staticfiles_urlpatterns()
