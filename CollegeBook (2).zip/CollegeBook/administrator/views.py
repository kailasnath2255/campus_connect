from urllib import request

from django.http import (HttpResponse,HttpResponseRedirect)
from django.shortcuts import render
import MySQLdb
import datetime
now = datetime.datetime.now()
import simplejson as json
import smtplib 
import random
import urllib.request
import webbrowser
from django.core.files.storage import FileSystemStorage
# Create your views here.

def sendmail(toadd,msg):

    #create smtp session
    s = smtplib.SMTP('smtp.gmail.com',587)

    #start TLS for security
    s.starttls()

    #Authentication
    s.login("gmedifile@gmail.com","gmedifile123")

    #Message you need to be send
    
    #Sending the mail
    s.sendmail("gmedifile@gmail.com",toadd,msg)

    #terminating the session
    s.quit()
    
def sendsms(ph,msg):

    sendToPhoneNumber= "+91"+ph
    userid = "2000022557"
    passwd = "54321@lcc"
    url = "http://enterprise.smsgupshup.com/GatewayAPI/rest?method=sendMessage&send_to=" + sendToPhoneNumber + "&msg=" + msg + "&userid=" + userid + "&password=" + passwd + "&v=1.1&msg_type=TEXT&auth_scheme=PLAIN"
    # contents = urllib.request.urlopen(url)
    webbrowser.open(url)


conn = MySQLdb.connect("localhost","root","","college_book")
c = conn.cursor()

def index_header_footerview(request):   
    return render(request,"index_header_footer.html")

def indexview(request): 
    message = ""
    if 'login' in request.POST:
        try:
            mail = request.POST.get("mail")
            password = request.POST.get("password")
            s = "select * from login where username='"+str(mail)+"' and password='"+str(password)+"' and status='1' "
            print(s)
            c.execute(s)
            conn.commit()
            log_count = c.fetchone()
            print(log_count)
            if log_count[4] == "admin":
                return HttpResponseRedirect("/admin_homeview")
            elif log_count[4] == "teacher":
                print("hhhhhhhhhhhhhhhhhhh")
                request.session["register_id"]=log_count[1]
                request.session["username"]=log_count[2]
                request.session["type"]=log_count[4]
                return HttpResponseRedirect("/teacher_homeview")
            elif log_count[4] == "parent":
                print("hhhhhhhhhhhhhhhhhhh")
                # request.session["register_id"]=log_count[1]
                request.session["username"]=log_count[2]
                request.session["type"]=log_count[4]
                return HttpResponseRedirect("/parent_home")  
            elif log_count[4] == "student":
                print("hhhhhhhhhhhhhhhhhhh")
                # request.session["register_id"]=log_count[1]
                request.session["username"]=log_count[2]
                request.session["type"]=log_count[4]
                return HttpResponseRedirect("/student_home")  
            else:
                message = "Invalid User"
                return render(request,"index.html",{"message":message})
            
        except:
            message = "Invalid User"
        return render(request,"index.html",{"message":message})
    return render(request,"index.html",{"message":message})

def registrationview(request):
    message = ""
    if 'register' in request.POST:
        name = request.POST.get("name")
        mail = request.POST.get("mail")
        phone = request.POST.get("phone")
        password = request.POST.get("password")
        qua = request.POST.get("qua")
        exp = request.POST.get("exp")
        
        uploaded_file_url=""
        
            
        # myfile=request.FILES.get("f1")
        # fs=FileSystemStorage()
        # filename=fs.save(myfile.name , myfile)
        # uploaded_file_url = fs.url(filename)

        s = "select count(*) from registration where register_name='"+str(name)+"' and register_mail='"+str(mail)+"'"
        c.execute(s)
        conn.commit()
        log_count = c.fetchone()
        if(log_count[0] == 0):
            s2 = "insert into registration(`register_name`,`register_mail`,`register_phone`,qualification,experience) values('"+str(name)+"','"+str(mail)+"','"+str(phone)+"','"+str(qua)+"','"+str(exp)+"')"
            c.execute(s2)
            conn.commit()
            s1 = "insert into login(`register_id`,`username`,`password`,`type`,`status`) values((select max(register_id) from registration),'"+str(mail)+"','"+str(password)+"','teacher','1')"
            print(s1)
            c.execute(s1)
            conn.commit()
            msg = "Registration successfull. \n User Name : "+str(name)+"\nPassword : "+str(password)
            # sendsms(phone,msg)
            # return HttpResponseRedirect("http://dattaanjaneya.biz/API_Services/SMS_Service.php?content="+msg+"&mobile="+phone+"")

            message="Registration Successfull"
            return render(request,"registration.html",{"message":message})
        else:
            message="Already Registered"
            return render(request,"registration.html",{"message":message})

    if 'login' in request.POST:
        try:
            mail = request.POST.get("mail")
            password = request.POST.get("password")
            s = "select * from login where username='"+str(mail)+"' and password='"+str(password)+"' and status='1' "
            print(s)
            c.execute(s)
            conn.commit()
            log_count = c.fetchone()
            if log_count[4] == "admin":
                return HttpResponseRedirect("/admin_homeview")
            elif log_count[4] == "teacher":
                request.session["register_id"]=log_count[1]
                request.session["username"]=log_count[2]
                request.session["type"]=log_count[4]
                return HttpResponseRedirect("/indexview")
            else:
                message = "Invalid User"
                return render(request,"index.html",{"message":message})
            
        except:
            message = "Invalid User"
        return render(request,"index.html",{"message":message})
    return render(request,"registration.html")

#----------------admin---------------------#

def admin_header_footerview(request):
    return render(request,"admin_header_footer.html")

def admin_homeiew(request):
    return render(request,"admin_home.html")

def approve_teacherview(request):
    s = "select r.register_id, r.register_name, r.register_mail, r.register_phone from registration r join login l where r.register_id = l.register_id and status='0'"
    c.execute(s)
    conn.commit()
    print(s)
    data = c.fetchall()
    print(data)
    return render(request,"approve_teacher.html",{"data":data})

def send_att_sms(request):
    st_id = request.GET.get("st_id")
    s = "select * from student where stud_id = '"+str(st_id)+"'"
    c.execute(s)
    conn.commit()
    data = c.fetchall()
    print(s)
    today = now.date()
    att = request.GET.get("att")
    pt_phone = request.GET.get("pt_phone")
    msg = "Your Child "+data[0][2]+" is "+str(att)+" "+str(today)
    # sendsms(pt_phone,msg)
    return HttpResponseRedirect("/a_view_attendance")

def teacher_delete(request):
    t_id = request.GET.get("t_id")
    s = "delete from registration where register_id = '"+str(t_id)+"'"
    c.execute(s)
    conn.commit()
    print(s)
    return HttpResponseRedirect("/view_teacheriew")
def update_approve_teacherview(request):
    status = request.GET.get("status")
    print(status)
    print("HAIIIIIIIII")
    if status == 'Approve':
        print("------------------Inside If-------------")
        register_id = request.GET.get("reg_id")
        s = "update login set status = '1' where register_id = '"+str(register_id)+"'"
        c.execute(s)
        conn.commit()
        print(s)
        return render(request,"approve_teacher.html")
    if status == 'Reject':
        print("------------------Inside If-------------")
        register_id = request.GET.get("reg_id")
        s = "delete from registration where register_id = '"+str(register_id)+"'"
        c.execute(s)
        conn.commit()
        print(s)
        s1 = "delete from login where register_id = '"+str(register_id)+"'"
        c.execute(s1)
        conn.commit()
        print(s1)
        return render(request,"approve_teacher.html")
    if status == 'ApproveAttendance':
        print("------------------Inside If-------------")
        register_id = request.GET.get("reg_id")
        s = "update login set status = '1', attendance = '1' where register_id = '"+str(register_id)+"'"
        c.execute(s)
        conn.commit()
        print(s)
        return render(request,"approve_teacher.html")
    return render(request,"approve_teacher.html")

def view_teacheriew(request):
    s = "select r.register_id, r.register_name, r.register_mail, r.register_phone, r.qualification, r.experience, r.image,l.attendance from registration r join login l where r.register_id = l.register_id and status='1'"
    c.execute(s)
    conn.commit()
    print(s)
    data = c.fetchall()
    print(data)
    return render(request,"view_teacher.html",{"data":data})


def add_coursesview(request):
    message = ""
    if request.POST:
        print("inside if")
        c_name = request.POST.get("c_name")
        c_duration = request.POST.get("c_duration")
        print(c_duration)
        ss = "select count(*) from course where course_name = '"+str(c_name).upper()+"'"
        c.execute(ss)
        conn.commit()
       
        course_count = c.fetchone()
        print(course_count[0])
        if course_count[0] == 0: 
            s = "insert into course(`course_name`,`course_duration`) values('"+str(c_name).upper()+"','"+str(c_duration)+"')"
            c.execute(s)
            conn.commit()
            print(s)
            message = "Course Added Successfully"
            return render(request,"add_courses.html",{"message":message})
        else:
            message = "Course Already Exists"
            return render(request,"add_courses.html",{"message":message})
    return render(request,"add_courses.html",{"message":message})

def view_coursesview(request):
    s = "select * from course"
    c.execute(s)
    conn.commit()
    print(s)
    data = c.fetchall()
    print(data)
    return render(request,"view_courses.html",{"data":data})

def academic_yearview(request):
    message = ""
    now_year = int(now.year)

    s1 = "select * from academic_year"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()
    if request.POST:
        print("inside if")
        start_year = int(request.POST.get("start_year"))
        end_year = int(request.POST.get("end_year"))
        if start_year > end_year or start_year < (now_year-3) or end_year < now_year :
            message = "Please enter valid Starting year"
            return render(request,"academic_year.html",{"message":message})
        else:
            ss = "select count(*) from academic_year where academic_year = '"+str(start_year).strip()+"-"+str(end_year).strip()+"'"
            c.execute(ss)
            conn.commit()
        
            year_count = c.fetchone()
            print(year_count[0])
            if year_count[0] == 0: 
                s = "insert into academic_year(`academic_year`) values('"+str(start_year).strip()+"-"+str(end_year).strip()+"')"
                c.execute(s)
                conn.commit()
                print(s)
                message = "Academic Year Added Successfully"
                return render(request,"academic_year.html",{"message":message,"data":data})
            else:
                message = "Academic year Already Exists"
                return render(request,"academic_year.html",{"message":message,"data":data})
    return render(request,"academic_year.html",{"message":message,"data":data})


def add_studentsview(request):
    message = ""

    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()

    if request.POST:
        print("inside if")
        course = request.POST.get("course")
        academic_year = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        st_register_no = request.POST.get("st_register_no")
        st_name = request.POST.get("st_name")
        st_email = request.POST.get("st_email")
        st_phone = request.POST.get("st_phone")
        pt_name = request.POST.get("pt_name")
        pt_phone = request.POST.get("pt_phone")

        s3 = "select count(*) from student where stud_register_no = '"+str(st_register_no)+"' or stud_mail = '"+str(st_email)+"'"
        c.execute(s3)
        conn.commit()
        print(s3)
        data2 = c.fetchone()
        if  data2[0] == 0 :
            ss = "insert into student(`stud_register_no`,`stud_name`,`stud_mail`,`stud_phone`,`parent_name`,`parent_phone`,`course`,`academic_year`,`semester`) values('"+str(st_register_no)+"','"+str(st_name)+"','"+str(st_email)+"','"+str(st_phone)+"','"+str(pt_name)+"','"+str(pt_phone)+"','"+str(course)+"','"+str(academic_year)+"','"+str(semester)+"')"
            c.execute(ss)
            ss = "insert into login(`register_id`,`username`,`password`,`type`,`status`) values('"+str(st_register_no)+"','"+str(st_email)+"','"+str(st_register_no)+"','student','1')"
            c.execute(ss)
            random_num=random.randrange(1000000,10000000000,2)
            ss = "insert into login(`register_id`,`username`,`password`,`type`,`status`) values('0','"+str(pt_phone)+"','"+str(random_num)+"','parent','1')"
            c.execute(ss)
            msg="Your Username is '"+str(pt_phone)+"' and Password is '"+str(random_num)+"' "
            # return HttpResponseRedirect("http://dattaanjaneya.biz/API_Services/SMS_Service.php?content="+msg+"&mobile="+pt_phone+"")
            # sendsms(pt_phone,msg)
            conn.commit()
            message = "Added Student Successfully"
            return render(request,"add_students.html",{"message":message,"data":data,"data1":data1})
        else:
            message = "Student Detail Already Exists"
            return render(request,"add_students.html",{"message":message,"data":data,"data1":data1})
    
    return render(request,"add_students.html",{"message":message,"data":data,"data1":data1})

def viewmonthly(request):
    msg = "" 
    st_id = request.GET.get("st_id")
    atdate = request.GET.get("att")
    phone = request.GET.get("pt_phone")
    # sem = request.GET.get("sem")
    # print(exam_id)
    print("inside view")
    print(atdate)
    mdate=atdate[5:7]
    print(mdate)
    today = now.date()
    st=5
    s = "select count(*) as cnt  from attendance where stud_id=  '"+str(st_id)+"'and month(date) = '"+str(mdate)+"' and attendance='"+str(st)+"'"
    c.execute(s)
    print(s)
    conn.commit()
    data1 = c.fetchone()
    fullday=data1[0]
    print(data1)
    st1=2.5
    s1 = "select count(*) as cnt  from attendance where stud_id=  '"+str(st_id)+"'and month(date) = '"+str(mdate)+"' and attendance='"+str(st1)+"'"
    c.execute(s1)
    print(s1)
    conn.commit()
    data11 = c.fetchone()
    halfday=data11[0]
    print(data11)
    st1=0
    s11 = "select count(*) as cnt  from attendance where stud_id=  '"+str(st_id)+"'and month(date) = '"+str(mdate)+"' and attendance='"+str(st1)+"'"
    c.execute(s11)
    print(s11)
    conn.commit()
    data111 = c.fetchone()
    absent=data111[0]
    print(data111)
    return render(request,"view_monthly.html",{"f":fullday,"h":halfday,"ab":absent,"da":mdate})

def view_studentsview(request):
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    print("inside if")

    if 'search' in request.POST:
        print("inside if")
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        s3 = "select * from student where course='"+str(c_id)+"' and academic_year='"+str(y_id)+"' order by stud_register_no"
        c.execute(s3)
        print(s3)
        conn.commit()
        data2 = c.fetchall()
        print(data2)
        return render(request,"view_students.html",{"data":data,"data1":data1,"data2":data2,"c_id":c_id,"y_id":y_id})
    return render(request,"view_students.html",{"data":data,"data1":data1})

def del_studentview(request):
    stud_id = request.GET.get("stud_id")
   
    print(stud_id)
    
    s = "delete from student where stud_id='"+str(stud_id)+"'"
    c.execute(s)
    conn.commit()
    
    return HttpResponseRedirect("/view_studentsview")

def admin_editstudent(request):
    stud_id = request.GET.get("stud_id")
    request.session["studed"]=stud_id
    print(stud_id)
    
    s = "select * from student where stud_id='"+str(stud_id)+"'"
    c.execute(s)
    conn.commit()
    data1=c.fetchall()
    if 'upstudent' in request.POST:
        stid=request.session["studed"]
        sn = request.POST.get("st_name")
        se = request.POST.get("st_email")
        sp = request.POST.get("st_phone")
        spn = request.POST.get("pt_name")
        s = "update student set stud_name='"+sn+"',stud_mail='"+se+"',stud_phone='"+sp+"',parent_name='"+spn+"' where stud_id='"+str(stid)+"'"
        c.execute(s)
        conn.commit()
        return HttpResponseRedirect("/view_studentsview/")
    return render(request,'admineditprofile.html',{'data1':data1})

  
def add_subjectview(request):
    message = ""

    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    # s2 = "select * from academic_year order by academic_year DESC"
    # c.execute(s2)
    # conn.commit()
    # data1 = c.fetchall()

    if 'subject' in request.POST:
        c_id = request.POST.get("course")
        semester = request.POST.get("semester")
        sub1 = request.POST.get("sub1")
        sub2 = request.POST.get("sub2")
        sub3 = request.POST.get("sub3")
        sub4 = request.POST.get("sub4")
        sub5 = request.POST.get("sub5")
        sub6 = request.POST.get("sub6")
        s = "select count(*) from subject where course_id = '"+str(c_id)+"' and semester='"+str(semester)+"'"
        c.execute(s)
        conn.commit()
        data1 = c.fetchone()
        if data1[0] == 0 :
            s1 = "insert into subject(`course_id`,`semester`,`sub1`,`sub2`,`sub3`,`sub4`,`sub5`,`sub6`) values('"+str(c_id)+"','"+str(semester)+"','"+str(sub1)+"','"+str(sub2)+"','"+str(sub3)+"','"+str(sub4)+"','"+str(sub5)+"','"+str(sub6)+"')"
            c.execute(s1)
            conn.commit()
            message = "Subjects Inserted Successfully..."
            return render(request,"add_subject.html",{"data":data,"message":message})
        else:
            message = "Already Exists"
            return render(request,"add_subject.html",{"data":data,"message":message})
    return render(request,"add_subject.html",{"data":data,"message":message})

def add_examview(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()

    if 'add_exam' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        exam_name = request.POST.get("exam_name")
        exam_detail = request.POST.get("exam_detail")
       
        s = "insert into exam(`course_id`,`academic_year`,`semester`,`exam_name`,`exam_detail`,`posted_date`) values('"+str(c_id)+"','"+str(y_id)+"','"+str(semester)+"','"+str(exam_name)+"','"+str(exam_detail)+"','"+str(today)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"add_exam.html",{"data":data,"data1":data1,"message":message})

def view_examview(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall() 
    
    if 'view_exam' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        print("inside if")


        s = "select *  from exam x , course c, academic_year y where c.course_id = '"+str(c_id)+"' and  x.course_id =  '"+str(c_id)+"' and y.year_id = '"+str(y_id)+"' and x.semester = '"+str(semester)+"' and x.academic_year =  '"+str(y_id)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        return render(request,"view_exam.html",{"data":data,"data1":data1,"data2":data2})
    return render(request,"view_exam.html",{"data":data,"data1":data1})

def a_exams(request):  
    msg = "" 
    exam_id = request.GET.get("exam_id")
    c_id = request.GET.get("c_id")
    y_id = request.GET.get("y_id")
    sem = request.GET.get("sem")
    print(exam_id)
    print("inside view")
    s = "select * from student s, course c, academic_year y,mark m where s.course = '"+str(c_id)+"' and s.academic_year = '"+str(y_id)+"' and s.semester = '"+str(sem)+"' and c.course_id= '"+str(c_id)+"' and y.year_id = '"+str(y_id)+"' and m.exam_id='"+str(exam_id)+"' and m.student_id = s.stud_id"
    c.execute(s)
    print(s)
    conn.commit()
    data1 = c.fetchall()
    print(data1)

    s1 = "select * from exam where exam_id ='"+str(exam_id)+"'"
    c.execute(s1)
    print(s1)
    conn.commit()
    data2 = c.fetchall()
    print(data1)

    s2 = "select * from subject where course_id='"+str(c_id)+"' and semester='"+str(sem)+"'"
    c.execute(s2)
    print(s2)
    conn.commit()
    data3 = c.fetchall()
    if not bool(data1):
        msg = " No student list to show"
    return render(request,"a_exams.html",{"msg":msg,"data1":data1,"exam_id":exam_id,"c_id":c_id,"y_id":y_id,"sem":sem,"data2":data2,"data3":data3})


def a_view_attendance(request):
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    today = now.date()
    if 'attendance' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        # period = request.POST.get("period")
        semester = request.POST.get("semester")
        s3 = "select * from student s, attendance a where s.course='"+str(c_id)+"' and s.academic_year='"+str(y_id)+"' and s.semester = '"+str(semester)+"' and a.stud_id = s.stud_id and a.c_id = s.course and a.semester = s.semester  order by stud_register_no"
        c.execute(s3)
        print(s3)
        conn.commit()
        data2 = c.fetchall()
        print(data2)

        
        return render(request,"a_view_attendance.html",{"data":data,"data1":data1,"data2":data2,"c_id":c_id,"y_id":y_id})

    return render(request,"a_view_attendance.html",{"data":data,"data1":data1})

def add_fee(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()

    if 'add_fee' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        
        exam_detail = request.POST.get("exam_detail")
        
        s = "insert into fees(`course_id`,`academic_year`,`semester`,`feedesc`,`posted_date`) values('"+str(c_id)+"','"+str(y_id)+"','"+str(semester)+"','"+str(exam_detail)+"','"+str(today)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"add_fees.html",{"data":data,"data1":data1,"message":message})

def view_fee(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall() 
    
    if 'view_fees' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        print("inside if")


        s = "select *  from fees x , course c, academic_year y where c.course_id = '"+str(c_id)+"' and  x.course_id =  '"+str(c_id)+"' and y.year_id = '"+str(y_id)+"' and x.semester = '"+str(semester)+"' and x.academic_year =  '"+str(y_id)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        print(data2)
        return render(request,"view_fees.html",{"data":data,"data1":data1,"data2":data2})
    return render(request,"view_fees.html",{"data":data,"data1":data1})

def add_circular(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()

    if 'add_circular' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        
        exam_detail = request.POST.get("exam_detail")
        
        s = "insert into circular(`courseid`,`academic_year`,`semester`,`circulardesc`,`date`) values('"+str(c_id)+"','"+str(y_id)+"','"+str(semester)+"','"+str(exam_detail)+"','"+str(today)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"admin_addcircular.html",{"data":data,"data1":data1,"message":message})

def add_meeting(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()

    if 'add_event' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        # y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        
        exam_detail = request.POST.get("event")
        
        s = "insert into meeting(`courseid`,`semester`,`description`) values('"+str(c_id)+"','"+str(semester)+"','"+str(exam_detail)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"add_parentmeeting.html",{"data":data,"message":message})

def add_event(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()
    data1=""
    if 'add_event' in request.POST:
        print("Inside if ")
        # c_id = request.POST.get("c_name")
        course = request.POST.get("course")
        exam_detail = request.POST.get("event")
        
        s = "insert into event(`course`,`eventdesc`) values('"+str(course)+"','"+str(exam_detail)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"admin_addevent.html",{"data":data,"data1":data1,"message":message})

def add_calender(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()
    data1=""
    if 'add_event' in request.POST:
        print("Inside if ")
        # c_id = request.POST.get("c_name")
        # course = request.POST.get("course")
        exam_detail = request.POST.get("event")
        
        s = "insert into acalender(`activity`,`date`) values('"+str(exam_detail)+"','"+str(today)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"add_academic_calender.html",{"data":data,"data1":data1,"message":message})
def view_feedback(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from feedback"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()
    data1=""
    return render(request,"view_feedback.html",{"data":data,"message":message})


def add_notice(request):
    message = ""
   
    print(now.date())
    today = now.date()
    
    conn.commit()
    
    data1=""
    if 'add_event' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("start_year")
        # course = request.POST.get("t_year")
        exam_detail = request.POST.get("event")
        
        s = "insert into notice(`date`,`description`) values('"+str(c_id)+"','"+str(exam_detail)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"admin_addnotice.html",{"data1":data1,"message":message})

def add_achievement(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    data3=""
    if 'add_fee' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        course = request.POST.get("academic_year")
        exam_detail = request.POST.get("semester")
        request.session["course1"]=c_id
        request.session["a_y"]=course 
         
        request.session["examdetail"]=exam_detail 

        s = " select * from student where course='"+str(c_id)+"' and academic_year='"+str(course)+"' and semester='"+str(exam_detail)+"'"
        c.execute(s)
        print(s)
        conn.commit()
        data3=c.fetchall()
        print(data3)
        
    
    return render(request,"admin_addachievements.html",{"data":data,"data1":data1,"data3":data3})
def add_studentachievement(request):
    stid=request.GET.get("st_id")
    sn=request.GET.get("att")
   
    
    today = now.date()
    
    conn.commit()
    message=""
    data1=""
    if 'add_event' in request.POST:
        print("Inside if ")
        # c_id = request.POST.get("end_year")
        # course = request.POST.get("t_year")
        exam_detail = request.POST.get("event")
        cou=request.session["course1"]
        ay=request.session["a_y"]
         
        ed=request.session["examdetail"]
        s = "insert into achievement(`title`,`studid`,`sname`,`course`,`sem`) values('"+str(exam_detail)+"','"+str(stid)+"','"+str(sn)+"','"+str(cou)+"','"+str(ed)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"admin_addstudentachieve.html",{"data1":data1,"message":message})

def add_result(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    data3=""
    if 'add_fee' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        course = request.POST.get("academic_year")
        exam_detail = request.POST.get("semester")
        request.session["course1"]=c_id
        request.session["a_y"]=course 
         
        request.session["examdetail"]=exam_detail 

        s = " select * from student where course='"+str(c_id)+"' and academic_year='"+str(course)+"' and semester='"+str(exam_detail)+"'"
        c.execute(s)
        print(s)
        conn.commit()
        data3=c.fetchall()
        print(data3)
        
    
    return render(request,"admin_add result.html",{"data":data,"data1":data1,"data3":data3})
def add_studentresult(request):
    stid=request.GET.get("st_id")
    sn=request.GET.get("att")
   
    
    today = now.date()
    
    conn.commit()
    message=""
    data1=""
    if 'add_event' in request.POST:
        print("Inside if ")
        # c_id = request.POST.get("end_year")
        # course = request.POST.get("t_year")
        uploaded_file_url=""
       
            
        myfile=request.FILES.get("f1")
        fs=FileSystemStorage()
        filename=fs.save(myfile.name , myfile)
        uploaded_file_url = fs.url(filename)
        cou=request.session["course1"]
        ay=request.session["a_y"]
         
        ed=request.session["examdetail"]
        s = "insert into result(`result`,`studid`,`sname`,`course`,`sem`) values('"+str(uploaded_file_url)+"','"+str(stid)+"','"+str(sn)+"','"+str(cou)+"','"+str(ed)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"admin_addstudentresult.html",{"data1":data1,"message":message})

def add_material(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()

    if 'add_fee' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        
        sub = request.POST.get("end_year")
        
        uploaded_file_url=""
       
            
        myfile=request.FILES.get("f1")
        fs=FileSystemStorage()
        filename=fs.save(myfile.name , myfile)
        uploaded_file_url = fs.url(filename)
        s = "insert into material(`courseid`,`sem`,`subject`,`smaterial`) values('"+str(c_id)+"','"+str(semester)+"','"+str(sub)+"','"+str(uploaded_file_url)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"add_material.html",{"data":data,"data1":data1,"message":message})

def add_assignment(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()

    if 'add_fee' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        
        desc = request.POST.get("end_year")
        sub = request.POST.get("e_year")
        
        # uploaded_file_url=""
       
            
        # myfile=request.FILES.get("f1")
        # fs=FileSystemStorage()
        # filename=fs.save(myfile.name , myfile)
        # uploaded_file_url = fs.url(filename)
        s = "insert into assignment(`courseid`,`sem`,`subject`,`description`) values('"+str(c_id)+"','"+str(semester)+"','"+str(sub)+"','"+str(desc)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"add_assignment.html",{"data":data,"data1":data1,"message":message})



def add_syllabus(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()

    if 'add_fee' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        
        sub = request.POST.get("end_year")
        
        uploaded_file_url=""
       
            
        myfile=request.FILES.get("f1")
        fs=FileSystemStorage()
        filename=fs.save(myfile.name , myfile)
        uploaded_file_url = fs.url(filename)
        s = "insert into syllabus(`courseid`,`sem`,`subject`,`syllabus`) values('"+str(c_id)+"','"+str(semester)+"','"+str(sub)+"','"+str(uploaded_file_url)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"add_syllabus.html",{"data":data,"data1":data1,"message":message})

def add_timetable(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()

    if 'add_fee' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("course")
        # y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        
        # sub = request.POST.get("end_year")
        
        uploaded_file_url=""
       
            
        myfile=request.FILES.get("f1")
        fs=FileSystemStorage()
        filename=fs.save(myfile.name , myfile)
        uploaded_file_url = fs.url(filename)
        s = "insert into timetable(`courseid`,`sem`,`timetable`) values('"+str(c_id)+"','"+str(semester)+"','"+str(uploaded_file_url)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"add_timetable.html",{"data":data,"data1":data1,"message":message})





# def add_material(request):
#     message = ""
   
#     print(now.date())
#     today = now.date()
#     s1 = "select * from course"
#     c.execute(s1)
#     conn.commit()
#     data = c.fetchall()

#     s2 = "select * from academic_year order by academic_year DESC"
#     c.execute(s2)
#     conn.commit()
#     data1 = c.fetchall()

#     if 'add_fee' in request.POST:
#         print("Inside if ")
#         c_id = request.POST.get("course")
#         y_id = request.POST.get("academic_year")
#         semester = request.POST.get("semester")
        
#         exam_detail = request.POST.get("exam_detail")
        
#         s = "insert into material(`courseid`,`sem`,`semester`,`feedesc`,`posted_date`) values('"+str(c_id)+"','"+str(y_id)+"','"+str(semester)+"','"+str(exam_detail)+"','"+str(today)+"')"
#         c.execute(s)
#         conn.commit()
#         message="Added Successfully..."
        
    
#     return render(request,"add_fees.html",{"data":data,"data1":data1,"message":message})
