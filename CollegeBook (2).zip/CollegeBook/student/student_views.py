from django.shortcuts import render

from django.http import (HttpResponse,HttpResponseRedirect)
from django.shortcuts import render
import MySQLdb
import datetime
now = datetime.datetime.now()
import simplejson as json

# Create your views here.


conn = MySQLdb.connect("localhost","root","","college_book")
c = conn.cursor()

def student_header_footerview(request):   
    return render(request,"student_header_footer.html")

def student_home(request):   
    return render(request,"student_home.html")




def studentresult_view(request):  
    msg = "" 
    s = "select * from course"
    c.execute(s)
    print(s)
    conn.commit()
    datac = c.fetchall()
    s = "select * from academic_year"
    c.execute(s)
    print(s)
    conn.commit()
    data12 = c.fetchall()  
    

    # s1 = "select * from exam where exam_id ='"+str(exam_id)+"'"
    # c.execute(s1)
    # print(s1)
    # conn.commit()
    # data2 = c.fetchall()
    # print(data1)
    if 'view_mark' in  request.POST:
        print("inside view")
        c_id = request.POST.get("course")
        sno = request.POST.get("s_no")
        y_id = request.POST.get("academic_year")
        sem = request.POST.get("semester")
        s = "select * from student s, course c, academic_year y,mark m where s.course = '"+str(c_id)+"' and s.academic_year = '"+str(y_id)+"' and s.semester = '"+str(sem)+"' and c.course_id= '"+str(c_id)+"' and y.year_id = '"+str(y_id)+"'  and m.student_id = s.stud_id and s.stud_register_no='"+str(sno)+"'"
        c.execute(s)
        print(s)
        conn.commit()
        data1 = c.fetchall()
        print(data1)
       
        s2 = "select * from subject where course_id='"+str(c_id)+"' and semester='"+str(sem)+"'"
        c.execute(s2)
        print(s2)
        conn.commit()
        data3 = c.fetchall()
        if not bool(data1):
            msg = " No student list to show"
        co=1
        return render(request,"student_viewmark.html",{"msg":msg,"data1":data1,"c_id":c_id,"sem":sem,"data3":data3,"co":co})
    return render(request,"student_viewmark.html",{"data1":datac,"data2":data12})


def t_attendance_mark(request):
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    today = now.date()
    if 'view_mark' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("s_no")
        # period = request.POST.get("period")
        semester = request.POST.get("semester")
        s3 = "select * from student where course='"+str(c_id)+"' and academic_year='"+str(y_id)+"' and semester = '"+str(semester)+"' order by stud_register_no"
        c.execute(s3)
        print(s3)
        conn.commit()
        data2 = c.fetchall()
        print(data2)

        s4 = "select stud_id,attendance from attendance where c_id = '"+str(c_id)+"' and y_id = '"+str(y_id)+"' and semester = '"+str(semester)+"' and date = '"+str(today)+"'"
        c.execute(s4)
        print(s4)
        data4 = c.fetchall()
        print(data4)
        return render(request,"t_attendance_mark.html",{"data":data,"data1":data1,"data2":data2,"data4":data4,"c_id":c_id,"y_id":y_id})

    return render(request,"t_attendance_mark.html",{"data":data,"data1":data1})

def parent_view_fee(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall() 
    
    if 'view_fees' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        print("inside if")


        s = "select *  from fees x , course c, academic_year y where c.course_id = '"+str(c_id)+"' and  x.course_id =  '"+str(c_id)+"' and y.year_id = '"+str(y_id)+"' and x.semester = '"+str(semester)+"' and x.academic_year =  '"+str(y_id)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        print(data2)
        return render(request,"parent_view_fees.html",{"data":data,"data1":data1,"data2":data2})
    return render(request,"parent_view_fees.html",{"data":data,"data1":data1})

def view_circular(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall() 
    
    if 'view_circular' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        print("inside if")


        s = "select *  from circular x , course c, academic_year y where c.course_id = '"+str(c_id)+"' and  x.courseid =  '"+str(c_id)+"' and y.year_id = '"+str(y_id)+"' and x.semester = '"+str(semester)+"' and x.academic_year =  '"+str(y_id)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        print(data2)
        return render(request,"student_viewcircular.html",{"data":data,"data1":data1,"data2":data2})
    return render(request,"student_viewcircular.html",{"data":data,"data1":data1})
def view_result(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall() 
    
    if 'view_circular' in request.POST:
        c_id = request.POST.get("course")
        # y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        print("inside if")


        s = "select *  from result x , course c where c.course_id = '"+str(c_id)+"' and  x.course =  '"+str(c_id)+"'  and x.sem = '"+str(semester)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        print(data2)
        return render(request,"student_viewresult.html",{"data":data,"data1":data1,"data2":data2})
    return render(request,"student_viewresult.html",{"data":data,"data1":data1})
def view_notice(request):  
    s1 = "select * from notice"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

   
    return render(request,"student_viewnotice.html",{"data":data})
def view_event(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    
    
    if 'view_circular' in request.POST:
        c_id = request.POST.get("course")
        # y_id = request.POST.get("academic_year")
        # semester = request.POST.get("semester")
        # print("inside if")


        s = "select *  from event x , course c where c.course_id = '"+str(c_id)+"' and  x.course =  '"+str(c_id)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        print(data2)
        return render(request,"student_viewevent.html",{"data":data,"data2":data2})
    return render(request,"student_viewevent.html",{"data":data})
def view_material(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall() 
    
    if 'view_circular' in request.POST:
        c_id = request.POST.get("course")
        # y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        print("inside if")


        s = "select *  from material x , course c where c.course_id = '"+str(c_id)+"' and  x.courseid =  '"+str(c_id)+"'  and x.sem = '"+str(semester)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        print(data2)
        return render(request,"student_viewmaterial.html",{"data":data,"data1":data1,"data2":data2})
    return render(request,"student_viewmaterial.html",{"data":data,"data1":data1})

def view_assignment(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall() 
    
    if 'view_circular' in request.POST:
        c_id = request.POST.get("course")
        # y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        print("inside if")


        s = "select *  from assignment x , course c where c.course_id = '"+str(c_id)+"' and  x.courseid =  '"+str(c_id)+"'  and x.sem = '"+str(semester)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        print(data2)
        return render(request,"student_viewassignment.html",{"data":data,"data1":data1,"data2":data2})
    return render(request,"student_viewassignment.html",{"data":data,"data1":data1})


def view_syllabus(request):  
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall() 
    
    if 'view_circular' in request.POST:
        c_id = request.POST.get("course")
        # y_id = request.POST.get("academic_year")
        semester = request.POST.get("semester")
        print("inside if")


        s = "select *  from syllabus x , course c where c.course_id = '"+str(c_id)+"' and  x.courseid =  '"+str(c_id)+"'  and x.sem = '"+str(semester)+"'  " 
        c.execute(s)
        conn.commit()
        print(s)

        data2 = c.fetchall()
        print(data2)
        return render(request,"student_viewsyllabus.html",{"data":data,"data1":data1,"data2":data2})
    return render(request,"student_viewsyllabus.html",{"data":data,"data1":data1})



def view_academic(request):  
    s1 = "select * from acalender"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

   
    return render(request,"student_viewacademic.html",{"data":data})

def add_feedback(request):
    message = ""
   
    print(now.date())
    today = now.date()
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    ty="student"
    if 'register' in request.POST:
        print("Inside if ")
        c_id = request.POST.get("c_name")
        y_id = request.POST.get("c_duration")
        
       
        s = "insert into feedback(`title`,`description`,`type`) values('"+str(c_id)+"','"+str(y_id)+"','"+str(ty)+"')"
        c.execute(s)
        conn.commit()
        message="Added Successfully..."
        
    
    return render(request,"student_addfeedback.html",{"message":message})
def studentview_teacheriew(request):
    s = "select r.register_id, r.register_name, r.register_mail, r.register_phone, r.qualification, r.experience, r.image,l.attendance from registration r join login l where r.register_id = l.register_id and status='1'"
    c.execute(s)
    conn.commit()
    print(s)
    data = c.fetchall()
    print(data)
    return render(request,"student_viewteacher.html",{"data":data})
def stu_view_attendance(request):
    s1 = "select * from course"
    c.execute(s1)
    conn.commit()
    data = c.fetchall()

    s2 = "select * from academic_year order by academic_year DESC"
    c.execute(s2)
    conn.commit()
    data1 = c.fetchall()
    today = now.date()
    if 'attendance' in request.POST:
        c_id = request.POST.get("course")
        y_id = request.POST.get("academic_year")
        # period = request.POST.get("period")
        semester = request.POST.get("semester")
        s3 = "select * from student s, attendance a where s.course='"+str(c_id)+"' and s.academic_year='"+str(y_id)+"' and s.semester = '"+str(semester)+"' and a.stud_id = s.stud_id and a.c_id = s.course and a.semester = s.semester  order by stud_register_no"
        c.execute(s3)
        print(s3)
        conn.commit()
        data2 = c.fetchall()
        print(data2)

        
        return render(request,"student_viewattendence.html",{"data":data,"data1":data1,"data2":data2,"c_id":c_id,"y_id":y_id})

    return render(request,"student_viewattendence.html",{"data":data,"data1":data1})
def viewmonthlystu(request):
    msg = "" 
    st_id = request.GET.get("st_id")
    atdate = request.GET.get("att")
    phone = request.GET.get("pt_phone")
    # sem = request.GET.get("sem")
    # print(exam_id)
    print("inside view")
    print(atdate)
    mdate=atdate[5:7]
    print(mdate)
    today = now.date()
    st=5
    s = "select count(*) as cnt  from attendance where stud_id=  '"+str(st_id)+"'and month(date) = '"+str(mdate)+"' and attendance='"+str(st)+"'"
    c.execute(s)
    print(s)
    conn.commit()
    data1 = c.fetchone()
    fullday=data1[0]
    print(data1)
    st1=2.5
    s1 = "select count(*) as cnt  from attendance where stud_id=  '"+str(st_id)+"'and month(date) = '"+str(mdate)+"' and attendance='"+str(st1)+"'"
    c.execute(s1)
    print(s1)
    conn.commit()
    data11 = c.fetchone()
    halfday=data11[0]
    print(data11)
    st1=0
    s11 = "select count(*) as cnt  from attendance where stud_id=  '"+str(st_id)+"'and month(date) = '"+str(mdate)+"' and attendance='"+str(st1)+"'"
    c.execute(s11)
    print(s11)
    conn.commit()
    data111 = c.fetchone()
    absent=data111[0]
    print(data111)
    return render(request,"studentmonthly.html",{"f":fullday,"h":halfday,"ab":absent,"da":mdate})
